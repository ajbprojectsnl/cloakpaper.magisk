#!/system/bin/sh
# CloakPaper: Paper-mode tweaks for system comfort

# Set grayscale
settings put secure accessibility_display_daltonizer 0
settings put secure accessibility_display_daltonizer_enabled 1

# Set low brightness
settings put system screen_brightness 60

# Disable all animations
settings put global window_animation_scale 0
settings put global transition_animation_scale 0
settings put global animator_duration_scale 0

# Force dark mode
settings put secure ui_night_mode 2
